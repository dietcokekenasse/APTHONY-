package com.apthony.loveverse;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    int bg=Color.rgb(22,15,34), panel=Color.rgb(43,29,58), pink=Color.rgb(255,105,170), cream=Color.rgb(255,235,245);
    LinearLayout root, content;
    final String[][] games = {
      {"💋 Kiss, Marry, Date","Choose who gets each romantic role."},
      {"💗 Never Have I Ever","Take turns revealing cute or funny secrets."},
      {"👑 Bare Minimum or Princess Treatment","Decide whether each gesture is basic effort or royal treatment."},
      {"🫶 Green Flag or Red Flag","Judge relationship situations together."},
      {"🔥 Truth or Dare","Pick a truth or a playful dare."},
      {"🥹 How Well Do You Know Me?","Guess your partner's favourite things."},
      {"💌 Love Letter in 60 Seconds","Write a tiny love note before time runs out."},
      {"😳 Who Blushes First?","Send a compliment and see who gets shy."},
      {"🎧 Our Song Guess","Hum or describe a song for your partner."},
      {"🌹 Dream Date Picker","Build your perfect date together."},
      {"🧸 Virtual Hug Challenge","Choose the hug animation you would send."},
      {"😘 Kiss-O-Meter","Rate cute, fictional kiss scenarios."},
      {"💬 This or That: Couple Edition","Choose between two romantic options."},
      {"🌙 Midnight Talks","Answer thoughtful late-night questions."},
      {"🧠 Finish My Sentence","Predict how your partner completes a line."},
      {"📸 Memory Lane","Guess the memory from a clue."},
      {"🍓 Sweet or Spicy","Pick the vibe for a date-night prompt."},
      {"🎲 Dare Wheel","Spin for a lighthearted couple challenge."},
      {"💞 Love Language Match","Compare how you give and receive affection."},
      {"🕵️ Secret Admirer","Guess which compliment your partner wrote."},
      {"☕ Café Date Roleplay","Choose orders and create a mini date."},
      {"🎬 Movie Night Match","Find a movie mood you both like."},
      {"🌈 Couple Moodboard","Pick colours, places and date vibes."},
      {"🫣 Most Likely To","Point to who is most likely to do it."},
      {"💐 Compliment Battle","Take turns giving genuine compliments."},
      {"🧩 Two Truths and a Lie","Spot the lie in three statements."},
      {"💘 First Impression Replay","Share what you first noticed."},
      {"🗺️ Dream Trip Together","Build a fantasy trip as a team."},
      {"🎨 Draw My Mood","Describe a mood for your partner to sketch."},
      {"🧋 Snack Compatibility","Choose snacks for your ideal evening."},
      {"🧸 Cute Nickname Battle","Invent the cutest nickname."},
      {"💍 Future Us","Imagine a home, trip or tradition together."},
      {"🪄 Magic Wish","Grant each other a small imaginary wish."},
      {"🧡 Apology Language","Talk about what makes an apology feel real."},
      {"🫧 Comfort or Solution?","Choose whether to listen or problem-solve."},
      {"🎤 Serenade Challenge","Dedicate a song or sing a line."},
      {"🪩 Dance-Off Prompt","Pick a silly dance challenge."},
      {"🧁 Bake-Off Choices","Choose ingredients for a dream dessert."},
      {"🌻 Sunrise or Sunset","Build a shared perfect-day plan."},
      {"💌 Open When Notes","Create a note for a future moment."},
      {"🧭 Relationship Compass","Discuss values and boundaries."},
      {"🎮 Co-op Mission","Solve a tiny teamwork prompt."},
      {"🪞 Describe Me in 3 Words","Share three kind words."},
      {"🧃 Red Flag Court","Debate funny fictional scenarios."},
      {"🏆 Couple Awards","Give each other playful awards."},
      {"💟 Rate the Date Idea","Rate and improve date ideas."},
      {"🧸 Plushie Personality","Choose a plushie that matches your partner."},
      {"🌌 Constellation Wishes","Share three hopes for the future."},
      {"📱 Emoji Only Story","Tell a love story using emojis."},
      {"🧩 Guess My Answer","Predict each other's answers."},
      {"🫶 Reassurance Round","Share what helps you feel cared for."},
      {"🎁 Surprise Me","Choose a surprise date prompt."},
      {"🕯️ Candlelight Questions","Answer gentle romantic questions."},
      {"🧑‍🍳 Cook Together Plan","Create a meal plan as a team."},
      {"🏖️ Beach Day Choices","Plan your imaginary beach date."},
      {"💓 Heartbeat Countdown","Say one thing you appreciate."},
      {"📖 Our Story in 5 Lines","Create a tiny story about you two."},
      {"🪄 Compliment Roulette","Get a random compliment prompt."},
      {"🚀 Couple Bucket List","Add one shared adventure."},
      {"🌷 Daily Love Check-in","Share a mood and one need today."},
      {"🎇 Firework Finale","End with a meaningful appreciation."}
    };

    @Override public void onCreate(Bundle b){ super.onCreate(b); showHome(); }
    GradientDrawable shape(int color,int radius){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d; }
    TextView text(String s,int size,int color,boolean bold){
      TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
      if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setPadding(0,4,0,4); return t;
    }
    void base(String title){
      ScrollView scroll=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(1); root.setPadding(20,18,20,28); root.setBackgroundColor(bg);
      scroll.addView(root); setContentView(scroll);
      TextView brand=text("✦  APTHONY",25,cream,true); root.addView(brand);
      TextView sub=text(title,14,pink,true); sub.setPadding(0,0,0,18); root.addView(sub);
    }
    void card(String title,String desc,Runnable action){
      LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(16,13,16,13); box.setBackground(shape(panel,22));
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,11); root.addView(box,lp);
      box.addView(text(title,17,cream,true)); box.addView(text(desc,13,Color.rgb(213,190,220),false));
      box.setOnClickListener(v->action.run());
    }
    void showHome(){
      base("A little universe for two ♡");
      TextView hero=text("Your love story,\nyour own universe.",29,cream,true); root.addView(hero);
      TextView info=text("Anime-inspired couple game • 60 mini-games",14,pink,false); root.addView(info);
      card("💞  Explore 60 couple games","Questions, dares, love tests and date-night ideas",()->showGames());
      card("🏡  Our shared world","House, city, mall and date locations — coming in the online-world update",()->notice("Shared 3D world is planned for the next development phase."));
      card("📞  Couple call & chat","Private voice/video calling and messaging — online integration not connected yet",()->notice("Calling needs a secure real-time service and partner accounts. This starter build does not connect calls yet."));
      card("🔐  Invite your person","Online room codes and two-phone sync — coming soon",()->notice("Online multiplayer requires a backend. This first build is the offline playable foundation."));
      card("✨  About APTHONY","Version 0.1.0 • Built as an Android starter project",()->notice("APTHONY is your romantic mini-game universe."));
    }
    void showGames(){
      base("60 ways to play together ♡");
      EditText search=new EditText(this); search.setSingleLine(true); search.setHint("Search games…"); search.setTextColor(cream); search.setHintTextColor(0xffBBA8C6); search.setBackground(shape(panel,18)); search.setPadding(14,8,14,8); root.addView(search);
      LinearLayout list=new LinearLayout(this); list.setOrientation(1); root.addView(list);
      Runnable refresh=()->{ list.removeAllViews(); String q=search.getText().toString().toLowerCase(Locale.ROOT); for(String[] g:games){ if((g[0]+" "+g[1]).toLowerCase(Locale.ROOT).contains(q)){
        LinearLayout item=new LinearLayout(this); item.setOrientation(1); item.setPadding(14,12,14,12); item.setBackground(shape(panel,18)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,8,0,0); list.addView(item,p);
        item.addView(text(g[0],16,cream,true)); item.addView(text(g[1],13,0xffD5BEDC,false)); item.setOnClickListener(v->play(g[0],g[1]));
      }} };
      search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){refresh.run();} public void afterTextChanged(android.text.Editable e){}});
      refresh.run();
      TextView back=text("← Back to home",15,pink,true); back.setPadding(0,18,0,0); root.addView(back); back.setOnClickListener(v->showHome());
    }
    void play(String title,String desc){
      new AlertDialog.Builder(this).setTitle(title).setMessage(desc+"\n\nTake turns with your partner and make your own rules. Online turn-sync will be added in a later version.").setPositiveButton("Let's play ♡",(d,w)->{}).setNegativeButton("Close",null).show();
    }
    void notice(String msg){ new AlertDialog.Builder(this).setTitle("APTHONY ♡").setMessage(msg).setPositiveButton("Okay",null).show(); }
}
