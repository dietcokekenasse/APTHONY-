# APTHONY — Android starter project

An anime-romance themed Android starter app with 60 couple mini-game prompts, searchable game list, and a dark plum/pink visual theme.

## Current implementation
- Native Android Java app (no third-party runtime dependencies)
- Home screen and searchable list of 60 couple game prompts
- Prompt detail dialogs
- App ID: `com.apthony.loveverse`
- Minimum Android: 6.0 (API 23)

## Important: what is NOT implemented yet
This is a first playable offline foundation, **not** the complete online game described in the brief.
- No user accounts, pairing codes, real-time multiplayer sync or cloud saves
- No voice/video calling
- No shared 3D house/city, avatars or movement
- Some prompts are conversation starters rather than fully animated mini-games

Those features require additional development and backend/service setup. Video calling and multiplayer can have usage costs after free-tier limits. Do not advertise this starter as having those features.

## Build APK
Open this folder in Android Studio (current stable), allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
The generated debug APK will be under `app/build/outputs/apk/debug/`.

Build requirements: Android Studio, JDK 17 or newer, Android SDK platform 35, Android Gradle Plugin 8.7.3.

## Build from an Android phone using GitHub Actions
A cloud build workflow is included at `.github/workflows/build-apk.yml`.

1. Sign in to GitHub in Chrome and create a **public** repository named `APTHONY` (public repositories can use standard GitHub-hosted Actions at no charge under GitHub's current policy).
2. Upload the contents of this ZIP to the repository root (not the ZIP file itself). Ensure the `.github/workflows/build-apk.yml` file is included. GitHub's mobile website may make folder uploads awkward; use Chrome's Desktop site if needed.
3. Open the repository's **Actions** tab, select **Build APTHONY APK**, tap **Run workflow** (or push to `main` to trigger it).
4. When the run completes, open it and download the `APTHONY-debug-APK` artifact. Extract the ZIP and install the APK.

Never upload passwords, signing keys, API secrets, or private personal data to a public repository. The current app contains no user data or credentials.
